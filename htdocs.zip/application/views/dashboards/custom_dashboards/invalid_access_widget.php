<div class="text-center box mb20" style="height: 0;">
    <div class="box-content" style="vertical-align: middle"> 
        <div class="mb5"><span class="fa fa-ban" style="font-size: 500%;color: #d4d4d4;"></span></div>
        <div><?php echo lang("invalid_widget_access"); ?></div>        
    </div>
</div>