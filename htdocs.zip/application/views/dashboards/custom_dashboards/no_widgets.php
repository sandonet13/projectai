<div class="text-center box" style="height: 400px;">
    <div class="box-content" style="vertical-align: middle"> 
        <div class="mb15"><?php echo lang("your_selected_widgets_will_be_appear_here"); ?></div>
        <span class="fa fa-desktop" style="font-size: 1400%; color:#d8d8d8"></span>
    </div>
</div>  