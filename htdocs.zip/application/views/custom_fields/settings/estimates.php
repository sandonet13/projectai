<div class="panel panel-default mb0 p20">
    <div class="table-responsive general-form">
        <table id="custom-field-table-estimates" class="display no-thead b-t b-b-only no-hover" cellspacing="0" width="100%">            
        </table>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        loadCustomFieldTable("estimates");
    });
</script>