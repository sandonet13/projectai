<table id="recurring-expenses-table" class="display" cellspacing="0" width="100%">   
</table>
<script type="text/javascript">
    $(document).ready(function () {
        loadExpensesTable("#recurring-expenses-table", "recurring");
    });
</script>