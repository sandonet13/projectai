<table id="yearly-expenses-table" class="display" cellspacing="0" width="100%">      
</table>
<script type="text/javascript">
    $(document).ready(function() {
        loadExpensesTable("#yearly-expenses-table", "yearly");
    });
</script>