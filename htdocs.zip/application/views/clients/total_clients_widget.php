<div class="panel panel-primary">
    <a href="<?php echo get_uri("clients/index"); ?>" class="white-link">
        <div class="panel-body">
            <div class="widget-icon">
                <i class="fa fa-briefcase"></i>
            </div>
            <div class="widget-details">
                <h1><?php echo $total; ?></h1>
                <?php echo lang("total_clients"); ?>
            </div>
        </div>
    </a>
</div>