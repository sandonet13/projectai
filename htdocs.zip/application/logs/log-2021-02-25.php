<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-25 14:43:57 --> Severity: Warning --> fsockopen(): unable to connect to srv42.niagahoster.com:587 (Connection timed out) /var/www/project.audemars.co.id/system/libraries/Email.php 2069
ERROR - 2021-02-25 14:43:57 --> The following SMTP error was encountered: 110 Connection timed out<br />Unable to send email using PHP SMTP. Your server might not be configured to send mail using this method.<br /><pre>Date: Thu, 25 Feb 2021 14:43:52 +0700
From: &quot;Project Team Audemars&quot; &lt;project@audemars.co.id&gt;
Return-Path: &lt;project@audemars.co.id&gt;
To: irvan.sandoval@gmail.com
Subject: =?UTF-8?Q?Test=20message?=
Reply-To: &lt;project@audemars.co.id&gt;
User-Agent: CodeIgniter
X-Sender: project@audemars.co.id
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;60375538e9af7@audemars.co.id&gt;
Mime-Version: 1.0


Content-Type: multipart/alternative; boundary=&quot;B_ALT_60375538e9b09&quot;

This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_60375538e9b09
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit

This is a test message to check mail configuration.


--B_ALT_60375538e9b09
Content-Type: text/html; charset=UTF-8
Content-Transfer-Encoding: quoted-printable

This is a test message to check mail configuration.

--B_ALT_60375538e9b09--</pre>
