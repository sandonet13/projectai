ERROR - 2021-03-05 15:33:37 --> 404 Page Not Found: Material/view
ERROR - 2021-03-05 15:57:48 --> Severity: Notice --> Undefined variable: view_type /var/www/project.audemars.co.id/application/views/clients/info_widgets/tab.php 18
ERROR - 2021-03-05 15:57:48 --> Severity: Notice --> Undefined variable: view_type /var/www/project.audemars.co.id/application/views/clients/info_widgets/tab.php 29
ERROR - 2021-03-05 15:57:48 --> Severity: Notice --> Undefined variable: view_type /var/www/project.audemars.co.id/application/views/clients/info_widgets/tab.php 40
ERROR - 2021-03-05 15:57:48 --> Severity: Notice --> Undefined variable: view_type /var/www/project.audemars.co.id/application/views/clients/info_widgets/tab.php 51
