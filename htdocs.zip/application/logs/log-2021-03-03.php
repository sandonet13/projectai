<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-03 03:05:20 --> Severity: Notice --> Undefined variable: label_suggestions C:\xampp\htdocs\project1\application\views\material\edit_form.php 232
ERROR - 2021-03-03 03:05:44 --> Severity: Notice --> Undefined variable: label_suggestions C:\xampp\htdocs\project1\application\views\material\edit_form.php 232
ERROR - 2021-03-03 03:12:51 --> 404 Page Not Found: Projects/material
ERROR - 2021-03-03 17:17:05 --> 404 Page Not Found: Projects/material
ERROR - 2021-03-03 17:19:45 --> Severity: Notice --> Undefined property: stdClass::$start_date C:\xampp\htdocs\project1\application\views\material\modal_form.php 15
ERROR - 2021-03-03 17:24:01 --> 404 Page Not Found: Projects/material
ERROR - 2021-03-03 17:28:55 --> 404 Page Not Found: Projects/material
ERROR - 2021-03-03 17:36:02 --> Severity: Notice --> Undefined variable: label_suggestions C:\xampp\htdocs\project1\application\views\material\edit_form.php 232
ERROR - 2021-03-03 17:38:38 --> Severity: Notice --> Undefined variable: label_suggestions C:\xampp\htdocs\project1\application\views\material\edit_form.php 239
ERROR - 2021-03-03 18:09:21 --> Severity: Notice --> Undefined index: invoice C:\xampp\htdocs\project1\application\controllers\Material.php 111
ERROR - 2021-03-03 18:10:36 --> Severity: Notice --> Undefined index: invoice C:\xampp\htdocs\project1\application\controllers\Material.php 112
ERROR - 2021-03-03 18:14:25 --> The upload path does not appear to be valid.
ERROR - 2021-03-03 18:14:52 --> The upload path does not appear to be valid.
ERROR - 2021-03-03 18:17:50 --> The upload path does not appear to be valid.
ERROR - 2021-03-03 18:19:01 --> The upload path does not appear to be valid.
ERROR - 2021-03-03 18:19:16 --> The upload path does not appear to be valid.
ERROR - 2021-03-03 18:28:33 --> 404 Page Not Found: Files/206-307-1-SM4.pdf
ERROR - 2021-03-03 18:28:33 --> 404 Page Not Found: Files/206-307-1-SM4.pdf
ERROR - 2021-03-03 18:28:45 --> 404 Page Not Found: Files/system
ERROR - 2021-03-03 18:28:45 --> 404 Page Not Found: Files/system
ERROR - 2021-03-03 18:30:34 --> 404 Page Not Found: Files/system
ERROR - 2021-03-03 18:30:34 --> 404 Page Not Found: Files/system
ERROR - 2021-03-03 18:34:35 --> Severity: Notice --> Undefined variable: label_suggestions C:\xampp\htdocs\project1\application\views\material\edit_form.php 239
