<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-10 13:10:27 --> Severity: Warning --> fsockopen(): unable to connect to srv42.niagahoster.com:587 (Connection timed out) /var/www/project.audemars.co.id/system/libraries/Email.php 2069
ERROR - 2021-03-10 09:31:59 --> 404 Page Not Found: Dashboard/phpinfo.php
